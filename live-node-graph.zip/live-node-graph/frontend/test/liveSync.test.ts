import test from 'node:test';
import assert from 'node:assert/strict';
import { LiveSync, type GraphPayload, type NodeResult, type Outcome, type SyncStatus } from '../src/liveSync.ts';

const graph = (value: string): GraphPayload => ({ nodes: [{ id: 'n', type: 'number', data: { value } }], edges: [] });
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const ok = (revision: number, v: number): Outcome => ({ ok: true, revision, nodes: { n: { status: 'ok', value: v } } });

function harness(send: (g: GraphPayload, rev: number, signal: AbortSignal) => Promise<Outcome>, extra = {}) {
  const results: { revision: number; nodes: Record<string, NodeResult> }[] = [];
  const statuses: SyncStatus[] = [];
  const sync = new LiveSync({
    send,
    onResult: (revision, nodes) => results.push({ revision, nodes }),
    onStatus: (s) => statuses.push(s),
    debounceMs: 10,
    timeoutMs: 80,
    retryDelaysMs: [10, 20, 30],
    ...extra,
  });
  return { sync, results, statuses };
}

test('typing 1, 10, 100 quickly sends one request with the final value', async () => {
  const sent: string[] = [];
  const h = harness(async (g, rev) => { sent.push(String(g.nodes[0].data.value)); return ok(rev, 100); });
  for (const v of ['1', '10', '100']) h.sync.update(graph(v));
  await sleep(60);
  assert.deepEqual(sent, ['100']);
  assert.equal(h.results.length, 1);
  assert.equal(h.results[0].revision, 3);
});

test('an edit during a request aborts it and its late answer is never shown', async () => {
  const signals: AbortSignal[] = [];
  const answers: ((o: Outcome) => void)[] = [];
  const h = harness((_g, _rev, signal) => { signals.push(signal); return new Promise((res) => answers.push(res)); });
  h.sync.update(graph('1'));
  await sleep(30);
  h.sync.update(graph('10'));
  assert.equal(signals[0].aborted, true, 'previous request is cancelled');
  await sleep(30);
  answers[0](ok(1, 111)); // old answer arrives late, ignoring the abort
  answers[1](ok(2, 222));
  await sleep(10);
  assert.deepEqual(h.results.map((r) => r.nodes.n.value), [222]);
});

test('out-of-order responses: older answer arriving last is dropped', async () => {
  const answers: Record<number, (o: Outcome) => void> = {};
  const h = harness((_g, rev) => new Promise((res) => { answers[rev] = res; }));
  h.sync.update(graph('1'));
  await sleep(30);
  h.sync.update(graph('10'));
  await sleep(30);
  answers[2](ok(2, 10));
  await sleep(5);
  answers[1](ok(1, 1));
  await sleep(5);
  assert.deepEqual(h.results.map((r) => r.revision), [2]);
  assert.equal(h.statuses.at(-1)?.phase, 'ready');
});

test('a response echoing the wrong revision is ignored', async () => {
  const h = harness(async () => ok(99, 5));
  h.sync.update(graph('1'));
  await sleep(40);
  assert.equal(h.results.length, 0);
});

test('service down: shows unavailable, retries with backoff and recovers by itself', async () => {
  let calls = 0;
  const h = harness(async (_g, rev) => {
    calls += 1;
    return calls < 3 ? { ok: false, code: 'simulator_unavailable', message: 'down' } : ok(rev, 5);
  });
  h.sync.update(graph('1'));
  await sleep(150);
  assert.equal(calls, 3);
  const phases = h.statuses.map((s) => s.phase);
  assert.deepEqual(phases, ['pending', 'unavailable', 'unavailable', 'ready']);
  assert.equal(h.results.length, 1);
});

test('a hanging request times out and is retried', async () => {
  let calls = 0;
  const h = harness((_g, rev) => (++calls === 1 ? new Promise<Outcome>(() => {}) : Promise.resolve(ok(rev, 1))));
  h.sync.update(graph('1'));
  await sleep(250);
  const unavailable = h.statuses.find((s) => s.phase === 'unavailable');
  assert.ok(unavailable && unavailable.phase === 'unavailable' && unavailable.code === 'timeout');
  assert.equal(h.statuses.at(-1)?.phase, 'ready');
});

test('a rejected graph is not retried', async () => {
  let calls = 0;
  const h = harness(async () => { calls++; return { ok: false, code: 'bad_request', message: 'nope' }; });
  h.sync.update(graph('1'));
  await sleep(100);
  assert.equal(calls, 1);
  const last = h.statuses.at(-1);
  assert.ok(last?.phase === 'unavailable' && last.retryInMs === null);
});

test('a new edit cancels a pending retry and starts fresh', async () => {
  let calls = 0;
  const h = harness(async (_g, rev) => (++calls === 1 ? { ok: false, code: 'network', message: 'x' } : ok(rev, 7)), { retryDelaysMs: [500] });
  h.sync.update(graph('1'));
  await sleep(40);
  h.sync.update(graph('2'));
  await sleep(40);
  assert.equal(calls, 2);
  assert.equal(h.statuses.at(-1)?.phase, 'ready');
});

test('dispose stops everything', async () => {
  let calls = 0;
  const h = harness(async (_g, rev) => { calls++; return ok(rev, 1); });
  h.sync.update(graph('1'));
  h.sync.dispose();
  await sleep(40);
  assert.equal(calls, 0);
});
