import { NODE_SPECS, NODE_TYPE_KEYS } from './nodeRegistry';

export const DRAG_MIME = 'application/x-node-type';

export function Palette({ onAdd }: { onAdd: (type: string) => void }) {
  return (
    <aside className="palette">
      <h2>Nodes</h2>
      <p className="muted">Drag onto the canvas (or click).</p>
      {NODE_TYPE_KEYS.map((type) => (
        <div
          key={type}
          className="palette-item"
          draggable
          role="button"
          tabIndex={0}
          onDragStart={(e) => {
            e.dataTransfer.setData(DRAG_MIME, type);
            e.dataTransfer.effectAllowed = 'move';
          }}
          onClick={() => onAdd(type)}
          onKeyDown={(e) => e.key === 'Enter' && onAdd(type)}
        >
          <strong>{NODE_SPECS[type].label}</strong>
          <small>{NODE_SPECS[type].hint}</small>
        </div>
      ))}
    </aside>
  );
}
