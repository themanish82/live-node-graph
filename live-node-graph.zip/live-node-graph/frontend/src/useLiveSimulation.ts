import { useEffect, useMemo, useRef, useState } from 'react';
import type { Edge, Node } from '@xyflow/react';
import { simulate } from './api';
import { LiveSync, type GraphPayload, type NodeResult, type SyncStatus } from './liveSync';

export type Phase = 'pending' | 'ready' | 'unavailable';

export interface SimView {
  phase: Phase;
  results: Record<string, NodeResult>;
  status: SyncStatus;
}

/** Only what the backend cares about: ids, types, data and wires. Positions, selection and
 *  measured sizes are left out so dragging a node never triggers a simulation. */
export function toPayload(nodes: Node[], edges: Edge[]): GraphPayload {
  return {
    nodes: nodes.map((n) => ({ id: n.id, type: n.type ?? '', data: { ...(n.data as Record<string, unknown>) } })),
    edges: edges.map((e) => ({
      source: e.source,
      target: e.target,
      sourceHandle: e.sourceHandle ?? null,
      targetHandle: e.targetHandle ?? null,
    })),
  };
}

export function useLiveSimulation(nodes: Node[], edges: Edge[]): SimView {
  const [status, setStatus] = useState<SyncStatus>({ phase: 'idle' });
  const [computed, setComputed] = useState<{ signature: string; nodes: Record<string, NodeResult> } | null>(null);
  const syncRef = useRef<LiveSync | null>(null);
  const signatureByRevision = useRef(new Map<number, string>());

  useEffect(() => {
    const sync = new LiveSync({
      send: simulate,
      onResult: (revision, results) => {
        const signature = signatureByRevision.current.get(revision);
        if (signature !== undefined) setComputed({ signature, nodes: results });
        for (const old of [...signatureByRevision.current.keys()]) if (old < revision) signatureByRevision.current.delete(old);
      },
      onStatus: setStatus,
    });
    syncRef.current = sync;
    return () => sync.dispose();
  }, []);

  const payload = useMemo(() => toPayload(nodes, edges), [nodes, edges]);
  const signature = useMemo(() => JSON.stringify(payload), [payload]);

  useEffect(() => {
    const sync = syncRef.current;
    if (!sync) return;
    sync.update(JSON.parse(signature) as GraphPayload);
    signatureByRevision.current.set(sync.currentRevision, signature);
  }, [signature]);

  // Results are only shown while they belong to the graph that is on the canvas right now.
  // This closes the one-frame gap between an edit and the effect above running.
  const fresh = computed?.signature === signature;
  let phase: Phase = 'pending';
  if (status.phase === 'unavailable') phase = 'unavailable';
  else if (fresh && status.phase === 'ready') phase = 'ready';
  return { phase, results: fresh ? computed!.nodes : {}, status };
}
