import { useContext } from 'react';
import { Handle, Position, useReactFlow, type Node, type NodeProps } from '@xyflow/react';
import { NODE_SPECS, OUTPUT_HANDLE } from './nodeRegistry';
import { SimContext } from './simContext';

type Data = { value?: string; expr?: string };

function format(v: number): string {
  return Number.isInteger(v) ? String(v) : String(parseFloat(v.toPrecision(10)));
}

/** One component renders every node type; what differs comes from the registry. */
export function GraphNode({ id, type, data, selected }: NodeProps<Node<Data>>) {
  const spec = NODE_SPECS[type] as (typeof NODE_SPECS)[string] | undefined;
  const { updateNodeData } = useReactFlow();
  const sim = useContext(SimContext);
  const result = sim.phase === 'ready' ? sim.results[id] : undefined;
  const state = result?.status ?? (sim.phase === 'unavailable' ? 'offline' : 'pending');

  let shown = '…';
  if (result?.status === 'ok' && result.value !== undefined) shown = format(result.value);
  else if (result?.status === 'blocked') shown = 'blocked';
  else if (result?.status === 'error') shown = 'error';
  else if (state === 'offline') shown = '—';

  if (!spec) return <div className="gnode state-error"><div className="gnode-body">Unknown node type “{type}”</div></div>;

  const isDisplay = type === 'display';
  return (
    <div className={`gnode state-${state}${selected ? ' selected' : ''}`} title={result?.message}>
      <div className="gnode-head">
        <span>{spec.label}</span>
        <small>{spec.hint}</small>
      </div>

      <div className="gnode-body">
        {spec.inputs.map((name, i) => (
          <Handle
            key={name}
            id={name}
            type="target"
            position={Position.Left}
            style={{ top: `${((i + 1) * 100) / (spec.inputs.length + 1)}%` }}
          >
            <span className="handle-label">{name}</span>
          </Handle>
        ))}

        {type === 'number' && (
          <input
            className="nodrag field"
            aria-label="value"
            inputMode="decimal"
            value={data.value ?? ''}
            onChange={(e) => updateNodeData(id, { value: e.target.value })}
          />
        )}
        {type === 'formula' && (
          <input
            className="nodrag field mono"
            aria-label="expression"
            spellCheck={false}
            value={data.expr ?? ''}
            onChange={(e) => updateNodeData(id, { expr: e.target.value })}
          />
        )}
        {(isDisplay || type !== 'number') && (
          <div className={`readout${isDisplay ? ' big' : ''}`}>
            {isDisplay ? shown : <>= {shown}</>}
          </div>
        )}
        {result && result.status !== 'ok' && <div className="note">{result.message}</div>}

        {spec.hasOutput && <Handle id={OUTPUT_HANDLE} type="source" position={Position.Right} />}
      </div>
    </div>
  );
}
