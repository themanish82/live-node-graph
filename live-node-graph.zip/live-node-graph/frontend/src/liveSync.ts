// Keeps the canvas in sync with the backend. Framework-free on purpose: all the hard rules
// (debounce, one request in flight, never show an older graph's results, retry) live here
// and are unit-tested without React or a browser.

export interface GraphPayload {
  nodes: { id: string; type: string; data: Record<string, unknown> }[];
  edges: { source: string; target: string; sourceHandle: string | null; targetHandle: string | null }[];
}

export interface NodeResult {
  status: 'ok' | 'error' | 'blocked';
  value?: number;
  message?: string;
  blockedBy?: string[];
}

export type Outcome =
  | { ok: true; revision: number | string | null; nodes: Record<string, NodeResult> }
  | { ok: false; code: string; message: string };

export type SyncStatus =
  | { phase: 'idle' }
  | { phase: 'pending'; revision: number }
  | { phase: 'ready'; revision: number }
  | { phase: 'unavailable'; revision: number; code: string; message: string; retryInMs: number | null };

export interface SyncOptions {
  send: (graph: GraphPayload, revision: number, signal: AbortSignal) => Promise<Outcome>;
  onResult: (revision: number, nodes: Record<string, NodeResult>) => void;
  onStatus: (status: SyncStatus) => void;
  debounceMs?: number;
  timeoutMs?: number;
  retryDelaysMs?: number[];
}

const NEVER_RETRY = new Set(['bad_request', 'bad_graph', 'simulator_rejected']);
// A graph that makes ngspice itself fail will probably fail again, so only retry those a little.
const LIMITED_RETRY = new Set(['solver_timeout', 'solver_failed']);

export class LiveSync {
  private revision = 0;
  private graph: GraphPayload | null = null;
  private controller: AbortController | null = null;
  private debounceTimer: ReturnType<typeof setTimeout> | undefined;
  private retryTimer: ReturnType<typeof setTimeout> | undefined;
  private attempt = 0;
  private disposed = false;

  private readonly opts: SyncOptions;

  constructor(opts: SyncOptions) {
    this.opts = opts;
  }

  /** Revision number of the most recent update() call. */
  get currentRevision(): number {
    return this.revision;
  }

  /** Call on every semantic change to the graph. Supersedes anything in flight or scheduled. */
  update(graph: GraphPayload): void {
    if (this.disposed) return;
    this.revision += 1;
    this.graph = graph;
    this.attempt = 0;
    this.controller?.abort();
    clearTimeout(this.debounceTimer);
    clearTimeout(this.retryTimer);
    this.opts.onStatus({ phase: 'pending', revision: this.revision });
    this.debounceTimer = setTimeout(() => void this.run(), this.opts.debounceMs ?? 150);
  }

  dispose(): void {
    this.disposed = true;
    this.controller?.abort();
    clearTimeout(this.debounceTimer);
    clearTimeout(this.retryTimer);
  }

  private async run(): Promise<void> {
    const revision = this.revision;
    const graph = this.graph;
    if (!graph) return;
    const controller = new AbortController();
    this.controller = controller;

    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, this.opts.timeoutMs ?? 10_000);
    const aborted = new Promise<Outcome>((resolve) =>
      controller.signal.addEventListener(
        'abort',
        () => resolve({ ok: false, code: timedOut ? 'timeout' : 'cancelled', message: 'The simulation service did not answer in time.' }),
        { once: true },
      ),
    );
    const sent = this.opts
      .send(graph, revision, controller.signal)
      .catch((): Outcome => ({ ok: false, code: 'network', message: 'Could not reach the server.' }));

    const outcome = await Promise.race([sent, aborted]);
    clearTimeout(timer);

    // Anything that is not about the latest graph is thrown away, whatever order answers arrive in.
    if (this.disposed || revision !== this.revision) return;
    if (outcome.ok) {
      if (outcome.revision !== revision) return;
      this.attempt = 0;
      this.opts.onResult(revision, outcome.nodes);
      this.opts.onStatus({ phase: 'ready', revision });
      return;
    }
    if (outcome.code === 'cancelled') return;
    this.fail(revision, outcome.code, outcome.message);
  }

  private fail(revision: number, code: string, message: string): void {
    const delays = this.opts.retryDelaysMs ?? [1000, 2000, 4000, 8000];
    const retryable = !NEVER_RETRY.has(code) && (!LIMITED_RETRY.has(code) || this.attempt < 2);
    if (!retryable) {
      this.opts.onStatus({ phase: 'unavailable', revision, code, message, retryInMs: null });
      return;
    }
    const delay = delays[Math.min(this.attempt, delays.length - 1)];
    this.attempt += 1;
    this.opts.onStatus({ phase: 'unavailable', revision, code, message, retryInMs: delay });
    this.retryTimer = setTimeout(() => {
      if (!this.disposed && revision === this.revision) void this.run();
    }, delay);
  }
}
