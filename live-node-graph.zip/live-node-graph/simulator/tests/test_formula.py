import unittest

from app import formula
from app.netlist import UnsafeNetlist, assemble

REJECTED = [
    "a\n.control\nshell ls", "a + b\n.end", "a; b", "sin(a)", "a ** 2", "a $ b", "A + b", "c", "a + ", "(a + b",
    "a b", "", "1e5", "a,b", "V(n1)", "a + b # x", "x" * 300, "a\r\n+ b", "a + b",
]
ACCEPTED = ["a", "a * 2 + b", "(a + b) / 2", "-a + 1.5", "a*b-.5", "  a +\tb  ", "-(-a)"]


class FormulaWhitelist(unittest.TestCase):
    def test_rejects_anything_outside_the_whitelist(self):
        for text in REJECTED:
            with self.subTest(text=text), self.assertRaises(formula.FormulaError):
                formula.parse(text)

    def test_accepts_whitelisted_expressions(self):
        for text in ACCEPTED:
            with self.subTest(text=text):
                formula.parse(text)

    def test_serialisation_comes_from_the_ast_not_the_input(self):
        out = formula.to_spice(formula.parse("a  *2+   b"), {"a": "n1", "b": "n2"})
        self.assertEqual(out, "((V(n1) * 2.0) + V(n2))")

    def test_deep_nesting_is_rejected_not_a_crash(self):
        with self.assertRaises(formula.FormulaError):
            formula.parse("(" * 100 + "a" + ")" * 100)

    def test_netlist_assembler_refuses_foreign_lines(self):
        with self.assertRaises(UnsafeNetlist):
            assemble([".control"])
        with self.assertRaises(UnsafeNetlist):
            assemble(["B1 n1 0 V = V(n2)\nshell ls"])


if __name__ == "__main__":
    unittest.main()
