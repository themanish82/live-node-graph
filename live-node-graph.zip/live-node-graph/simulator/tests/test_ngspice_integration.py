"""Runs real graphs through the real ngspice binary (skipped when it is not installed)."""
import shutil
import unittest

from app.engine import evaluate

from .support import node, wire


needs_ngspice = unittest.skipIf(shutil.which("ngspice") is None, "ngspice not installed")


class RealNgspice(unittest.IsolatedAsyncioTestCase):
    @needs_ngspice
    async def test_graphs_1_2_and_7(self):
        nodes = [node("a", "number", value="2"), node("b", "number", value="3"), node("add", "add"), node("n4", "number", value="4"),
                 node("mul", "multiply"), node("d", "display"), node("f", "formula", expr="a * 2 + b"), node("d2", "display")]
        edges = [wire("a", "add", "a"), wire("b", "add", "b"), wire("add", "mul", "a"), wire("n4", "mul", "b"), wire("mul", "d", "x"),
                 wire("a", "f", "a"), wire("b", "f", "b"), wire("f", "d2", "x")]
        r = await evaluate(nodes, edges)
        self.assertAlmostEqual(r["add"].value, 5)
        self.assertAlmostEqual(r["d"].value, 20)
        self.assertAlmostEqual(r["d2"].value, 7)

    @needs_ngspice
    async def test_divide_by_zero(self):
        nodes = [node("a", "number", value="10"), node("z", "number", value="0"), node("div", "divide"), node("d", "display")]
        edges = [wire("a", "div", "a"), wire("z", "div", "b"), wire("div", "d", "x")]
        r = await evaluate(nodes, edges)
        self.assertEqual((r["div"].status, r["d"].status), ("error", "blocked"))

    async def test_hang_is_killed(self):
        import os, stat, tempfile
        from app import ngspice

        with tempfile.TemporaryDirectory() as tmp:
            fake = os.path.join(tmp, "ngspice")
            open(fake, "w").write("#!/bin/sh\nsleep 30\n")
            os.chmod(fake, os.stat(fake).st_mode | stat.S_IEXEC)
            old = (ngspice.NGSPICE_BIN, ngspice.TIMEOUT_S)
            ngspice.NGSPICE_BIN, ngspice.TIMEOUT_S = fake, 0.3
            try:
                with self.assertRaises(ngspice.SolverTimeout):
                    await ngspice.run("* t\n.op\n.end\n")
            finally:
                ngspice.NGSPICE_BIN, ngspice.TIMEOUT_S = old


if __name__ == "__main__":
    unittest.main()
