"""Graph -> per-node results.

Pipeline:
  1. structural checks (unknown ids/handles) -> GraphError
  2. per-node checks that need no solver: bad data, unconnected / doubly-wired inputs
  3. loop detection (Tarjan strongly connected components)
  4. everything downstream of a problem node is *blocked*
  5. build a netlist for the rest and run ngspice. Nodes that can fail depending on a
     value (Divide, Formula with "/") are only added once their inputs are known and the
     divisor has been checked, so that a zero divisor is reported on the right node.
"""
from __future__ import annotations

import math
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Mapping

from . import ngspice
from .netlist import assemble
from .registry import REGISTRY

Runner = Callable[[str], Awaitable[dict[str, float]]]


class GraphError(ValueError):
    """The payload is malformed (as opposed to the user's graph being wrong)."""


@dataclass
class Result:
    status: str  # "ok" | "error" | "blocked"
    value: float | None = None
    message: str | None = None
    blocked_by: list[str] = field(default_factory=list)

    def to_json(self) -> dict:
        out: dict = {"status": self.status}
        if self.value is not None:
            out["value"] = self.value
        if self.message:
            out["message"] = self.message
        if self.blocked_by:
            out["blockedBy"] = self.blocked_by
        return out


def _strongly_connected(ids: list[str], succ: Mapping[str, list[str]]) -> list[list[str]]:
    """Iterative Tarjan so a deep chain cannot hit the recursion limit."""
    index: dict[str, int] = {}
    low: dict[str, int] = {}
    on_stack: set[str] = set()
    stack: list[str] = []
    out: list[list[str]] = []
    counter = 0
    for root in ids:
        if root in index:
            continue
        work = [(root, iter(succ[root]))]
        index[root] = low[root] = counter
        counter += 1
        stack.append(root)
        on_stack.add(root)
        while work:
            node, it = work[-1]
            advanced = False
            for nxt in it:
                if nxt not in index:
                    index[nxt] = low[nxt] = counter
                    counter += 1
                    stack.append(nxt)
                    on_stack.add(nxt)
                    work.append((nxt, iter(succ[nxt])))
                    advanced = True
                    break
                if nxt in on_stack:
                    low[node] = min(low[node], index[nxt])
            if advanced:
                continue
            work.pop()
            if work:
                parent = work[-1][0]
                low[parent] = min(low[parent], low[node])
            if low[node] == index[node]:
                comp = []
                while True:
                    w = stack.pop()
                    on_stack.discard(w)
                    comp.append(w)
                    if w == node:
                        break
                out.append(comp)
    return out


def find_loops(ids: list[str], edges: list[tuple[str, str]]) -> set[str]:
    succ: dict[str, list[str]] = {i: [] for i in ids}
    for s, t in edges:
        succ[s].append(t)
    loops: set[str] = set()
    for comp in _strongly_connected(ids, succ):
        if len(comp) > 1 or comp[0] in succ[comp[0]]:
            loops.update(comp)
    return loops


async def evaluate(payload_nodes: list[dict], payload_edges: list[dict], runner: Runner | None = None) -> dict[str, Result]:
    runner = runner or ngspice.run

    # ---- 1. structure -------------------------------------------------------------
    nodes: dict[str, dict] = {}
    for n in payload_nodes:
        if n["id"] in nodes:
            raise GraphError(f"duplicate node id {n['id']!r}")
        nodes[n["id"]] = n
    order = list(nodes)
    index = {nid: i for i, nid in enumerate(order)}
    wires: dict[tuple[str, str], list[str]] = defaultdict(list)  # (target, input) -> sources
    edges: list[tuple[str, str]] = []
    for e in payload_edges:
        s, t, th = e["source"], e["target"], e.get("targetHandle")
        if s not in nodes or t not in nodes:
            raise GraphError("edge refers to an unknown node")
        s_spec, t_spec = REGISTRY.get(nodes[s]["type"]), REGISTRY.get(nodes[t]["type"])
        if (s_spec and not s_spec.has_output) or (t_spec and th not in t_spec.inputs):
            raise GraphError("edge uses a handle that does not exist")
        wires[(t, th)].append(s)
        edges.append((s, t))

    errors: dict[str, str] = {}
    # ---- 2. per-node checks -------------------------------------------------------
    for nid, n in nodes.items():
        spec = REGISTRY.get(n["type"])
        if spec is None:
            errors[nid] = f"unknown node type {n['type']!r}"
            continue
        problem = spec.validate(n.get("data") or {})
        for name in spec.inputs:
            count = len(wires[(nid, name)])
            if count == 0 and problem is None:
                problem = f"input '{name}' is not connected"
            elif count > 1 and problem is None:
                problem = f"input '{name}' has more than one wire"
        if problem:
            errors[nid] = problem
    # ---- 3. loops -----------------------------------------------------------------
    for nid in find_loops(order, edges):
        errors.setdefault(nid, "part of a loop (a node depends on its own output)")

    downstream: dict[str, list[str]] = defaultdict(list)
    upstream: dict[str, list[str]] = defaultdict(list)
    for s, t in edges:
        downstream[s].append(t)
        upstream[t].append(s)

    blocked_by: dict[str, set[str]] = defaultdict(set)

    def fail(nid: str, message: str) -> None:
        errors[nid] = message
        block_descendants(nid)

    def block_descendants(root: str) -> None:
        seen, queue = {root}, deque([root])
        while queue:
            for nxt in downstream[queue.popleft()]:
                if nxt in seen:
                    continue
                seen.add(nxt)
                if nxt not in errors:
                    blocked_by[nxt].add(root)
                queue.append(nxt)

    for nid in list(errors):
        block_descendants(nid)

    # ---- 4/5. solve ---------------------------------------------------------------
    def pending() -> list[str]:
        return [n for n in order if n not in errors and n not in blocked_by]

    values: dict[str, float] = {}  # node id -> output value (Display: received value)
    cleared: set[str] = set()  # guarded nodes whose divisor has been checked

    def input_nets(nid: str) -> dict[str, str]:
        return {name: f"n{index[wires[(nid, name)][0]]}" for name in REGISTRY[nodes[nid]["type"]].inputs}

    def guarded_ancestors(nid: str) -> set[str]:
        seen, stack = set(), list(upstream[nid])
        while stack:
            cur = stack.pop()
            if cur in seen:
                continue
            seen.add(cur)
            stack.extend(upstream[cur])
        return {a for a in seen if REGISTRY[nodes[a]["type"]].guard}

    guard_deps = {nid: guarded_ancestors(nid) for nid in pending()}

    for _ in range(len(order) + 2):
        live = pending()
        included = [
            n for n in live
            if (not REGISTRY[nodes[n]["type"]].guard or n in cleared)
            and all(a in cleared for a in guard_deps[n])
        ]
        lines: list[str] = []
        line_owner: dict[str, str] = {}
        for nid in included:
            spec = REGISTRY[nodes[nid]["type"]]
            if spec.netlist:
                el = index[nid]
                line = spec.netlist(el, f"n{el}", input_nets(nid), nodes[nid].get("data") or {})
                lines.append(line)
                line_owner[line.split()[0].upper()] = nid
        raw: dict[str, float] = {}
        if lines:
            try:
                raw = await runner(assemble(lines))
            except ngspice.SolverFailed as exc:
                culprits = [line_owner[e] for e in exc.elements if e in line_owner]
                if not culprits:
                    raise
                for nid in culprits:
                    if nid not in errors:
                        fail(nid, f"ngspice: {exc.message}")
                continue
        values.clear()
        for nid in included:
            spec = REGISTRY[nodes[nid]["type"]]
            net = f"n{index[nid]}" if spec.has_output else input_nets(nid)["x"]
            if f"v({net})" in raw:
                values[nid] = raw[f"v({net})"]

        progressed = False
        for nid in live:
            spec = REGISTRY[nodes[nid]["type"]]
            if not spec.guard or nid in cleared or nid in errors:
                continue
            if any(a not in cleared for a in guard_deps[nid]):
                continue
            ins = {name: values.get(wires[(nid, name)][0]) for name in spec.inputs}
            if any(v is None for v in ins.values()):
                continue
            message = spec.guard(nodes[nid].get("data") or {}, ins)  # type: ignore[arg-type]
            progressed = True
            if message:
                fail(nid, message)
            else:
                cleared.add(nid)
        if not progressed:
            break

    # ---- results ------------------------------------------------------------------
    for nid in pending():
        if nid in blocked_by or nid in errors:  # became blocked while handling an earlier node
            continue
        value = values.get(nid)
        if value is None:
            fail(nid, "ngspice returned no value for this node")
        elif not math.isfinite(value):
            fail(nid, "result is not a finite number (overflow)")
    results: dict[str, Result] = {}
    for nid in order:
        if nid in errors:
            results[nid] = Result("error", message=errors[nid])
        elif nid in blocked_by:
            results[nid] = Result("blocked", message="blocked by an upstream error", blocked_by=sorted(blocked_by[nid]))
        else:
            results[nid] = Result("ok", value=values[nid])
    return results
