// Request validation / sanitising. Pure functions, no dependencies, so they are easy to test.

export class ValidationError extends Error {}

const MAX_NODES = 500;
const MAX_EDGES = 2000;
const NAME_RE = /^[\w .-]{1,60}$/;

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const str = (v, what, max) => {
  if (typeof v !== 'string' || v.length === 0 || v.length > max) throw new ValidationError(`${what} must be a string of 1-${max} characters`);
  return v;
};
const optStr = (v, what, max) => (v == null ? null : str(v, what, max));

function cleanData(data) {
  if (data == null) return {};
  if (!isObj(data)) throw new ValidationError('node data must be an object');
  const out = {};
  for (const [k, v] of Object.entries(data)) {
    if (k.length > 32) throw new ValidationError('node data key is too long');
    if (typeof v === 'string' && v.length <= 200) out[k] = v;
    else if (typeof v === 'number' && Number.isFinite(v)) out[k] = v;
    else if (typeof v === 'boolean') out[k] = v;
    else throw new ValidationError(`node data '${k}' must be a short string, number or boolean`);
  }
  return out;
}

/** Validate and strip a graph down to the fields we store / forward. */
export function cleanGraph(body, { requirePositions = false } = {}) {
  if (!isObj(body)) throw new ValidationError('body must be a JSON object');
  const { nodes, edges } = body;
  if (!Array.isArray(nodes) || nodes.length > MAX_NODES) throw new ValidationError(`nodes must be an array of at most ${MAX_NODES}`);
  if (!Array.isArray(edges) || edges.length > MAX_EDGES) throw new ValidationError(`edges must be an array of at most ${MAX_EDGES}`);
  return {
    nodes: nodes.map((n) => {
      if (!isObj(n)) throw new ValidationError('each node must be an object');
      const node = { id: str(n.id, 'node id', 64), type: str(n.type, 'node type', 32), data: cleanData(n.data) };
      const p = n.position;
      if (isObj(p) && Number.isFinite(p.x) && Number.isFinite(p.y)) node.position = { x: p.x, y: p.y };
      else if (requirePositions) throw new ValidationError('node position must be {x, y}');
      return node;
    }),
    edges: edges.map((e) => {
      if (!isObj(e)) throw new ValidationError('each edge must be an object');
      return {
        id: optStr(e.id, 'edge id', 200) ?? undefined,
        source: str(e.source, 'edge source', 64),
        target: str(e.target, 'edge target', 64),
        sourceHandle: optStr(e.sourceHandle, 'sourceHandle', 32),
        targetHandle: optStr(e.targetHandle, 'targetHandle', 32),
      };
    }),
  };
}

export function cleanName(name) {
  if (typeof name !== 'string' || !NAME_RE.test(name)) throw new ValidationError('name must be 1-60 letters, digits, spaces, . _ -');
  return name;
}
