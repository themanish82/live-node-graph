import test from 'node:test';
import assert from 'node:assert/strict';
import { createSimulatorClient } from '../src/simulator.js';

const graph = { nodes: [], edges: [] };
const json = (status, body) => async () => ({ ok: status < 400, status, json: async () => body });

test('passes successful results through', async () => {
  const c = createSimulatorClient({ baseUrl: 'http://x', fetchImpl: json(200, { revision: 3, nodes: {} }) });
  assert.deepEqual(await c.simulate(graph, 3), { status: 200, body: { revision: 3, nodes: {} } });
});

test('service down becomes a structured 503, not an exception', async () => {
  const c = createSimulatorClient({ baseUrl: 'http://x', fetchImpl: async () => { throw new TypeError('fetch failed'); } });
  const r = await c.simulate(graph, 7);
  assert.equal(r.status, 503);
  assert.equal(r.body.error.code, 'simulator_unavailable');
  assert.equal(r.body.revision, 7);
});

test('a hanging simulator times out', async () => {
  const hang = (_url, { signal }) => new Promise((_res, rej) => signal.addEventListener('abort', () => rej(signal.reason)));
  const c = createSimulatorClient({ baseUrl: 'http://x', timeoutMs: 30, fetchImpl: hang });
  const r = await c.simulate(graph, 1);
  assert.equal(r.status, 504);
  assert.equal(r.body.error.code, 'simulator_timeout');
});

test('client cancellation aborts the upstream call', async () => {
  let upstreamAborted = false;
  const hang = (_url, { signal }) => new Promise((_res, rej) => signal.addEventListener('abort', () => { upstreamAborted = true; rej(signal.reason); }));
  const c = createSimulatorClient({ baseUrl: 'http://x', timeoutMs: 5000, fetchImpl: hang });
  const clientCtrl = new AbortController();
  const p = c.simulate(graph, 1, clientCtrl.signal);
  clientCtrl.abort();
  assert.equal((await p).status, 499);
  assert.ok(upstreamAborted);
});

test('solver errors from python keep their code', async () => {
  const c = createSimulatorClient({ baseUrl: 'http://x', fetchImpl: json(504, { error: { code: 'solver_timeout', message: 'slow' } }) });
  const r = await c.simulate(graph, 2);
  assert.equal(r.status, 504);
  assert.equal(r.body.error.code, 'solver_timeout');
});

test('unreadable upstream response is a 502', async () => {
  const c = createSimulatorClient({ baseUrl: 'http://x', fetchImpl: async () => ({ ok: true, status: 200, json: async () => { throw new Error('bad'); } }) });
  assert.equal((await c.simulate(graph, 1)).status, 502);
});
